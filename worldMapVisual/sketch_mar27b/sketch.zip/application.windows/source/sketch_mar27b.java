import processing.core.*; 
import processing.xml.*; 

import processing.pdf.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class sketch_mar27b extends PApplet {


PFont font;
PImage mapImage;
int width = 1440;
int height = 900;

Table locationTable;
int rowCount;

Table commentTable;
int commentCount;

Table likeTable;
int likeCount;

long minTime;
long maxTime;

public void setup() {
  //size(width, height,PDF,"new.pdf");
  size(width, height);
  locationTable = new Table("completedubbs.txt");
  rowCount = locationTable.getRowCount();
  commentTable = new Table("comments.txt.output");
  commentCount = commentTable.getRowCount();
  likeTable = new Table("likes.txt.output");
  likeCount = likeTable.getRowCount();
  
  mapImage = loadImage("newdit.png");
  minTime = locationTable.getMinTime() - 100 * locationTable.getInterval();
  maxTime = locationTable.getMinTime() + 100 * locationTable.getInterval();
  
  font = loadFont("Times-Roman-16.vlw");
  textFont(font);
}

public void draw() {
  background(mapImage);
  
 
  
  if(maxTime > locationTable.getMaxTime() + locationTable.getInterval()) {
    fill(0,192,0);
    noStroke();
    for(int row = 0; row < rowCount; row++) {
      float x = locationTable.getIPLongitude(row);
      float y = locationTable.getIPLatitude(row);
      int r = 4;
      ellipse(transfromLongitude(x),transfromLatitude(y),r,r);
    }
    
    fill(0,0,192);
    noStroke();
    for(int row = 0; row < commentCount; row++) {
    
      float x = commentTable.getIPLongitude(row);
      float y = commentTable.getIPLatitude(row);
      int r = 4;
      ellipse(transfromLongitude(x),transfromLatitude(y),r,r);
    }
    
    fill(192,0,0);
    noStroke();
    for(int row = 0; row < likeCount; row++) {
    
      float x = likeTable.getIPLongitude(row);
      float y = likeTable.getIPLatitude(row);
      int r = 4;
      ellipse(transfromLongitude(x),transfromLatitude(y),r,r);
    }
    //save("final.png");
    //exit();
  } else {
    fill(0,192,0);
    noStroke();
    for(int row = 0; row < rowCount; row++) {
      long time = locationTable.getIPTime(row);
      if((time > minTime) && (time < maxTime)) {
        float x = locationTable.getIPLongitude(row);
        float y = locationTable.getIPLatitude(row);
        int r = 4;
        ellipse(transfromLongitude(x),transfromLatitude(y),r,r);
      }
    }
    
    fill(0,0,192);
    noStroke();
    for(int row = 0; row < commentCount; row++) {
      long time = commentTable.getIPTime(row);
      if((time > minTime) && (time < maxTime)) {
        float x = commentTable.getIPLongitude(row);
        float y = commentTable.getIPLatitude(row);
        int r = 4;
        ellipse(transfromLongitude(x),transfromLatitude(y),r,r);
      }
    }
    
    fill(192,0,0);
    noStroke();
    for(int row = 0; row < likeCount; row++) {
      long time = likeTable.getIPTime(row);
      if((time > minTime) && (time < maxTime)) {
        float x = likeTable.getIPLongitude(row);
        float y = likeTable.getIPLatitude(row);
        int r = 4;
        ellipse(transfromLongitude(x),transfromLatitude(y),r,r);
      }
    }
  }
  minTime += locationTable.getInterval();
  maxTime += locationTable.getInterval();
    
    
  Date date = new Date(maxTime);
  Calendar calendar = Calendar.getInstance();
  calendar.setTime(date);
  textAlign(LEFT);
  fill(0);
  String message = calendar.get(Calendar.YEAR) + "." + (calendar.get(Calendar.MONTH) + 1) + "." + calendar.get(Calendar.DAY_OF_MONTH);
  text(message, width/2, 50);
  
  textAlign(LEFT);
  fill(0,192,0);
  text("DUBB", 50, height - 400);
  fill(192,0,0);
  text("LIKE", 50, height - 350);
  fill(0,0,192);
  text("COMMENT",50,height - 300);
  
}

public float transfromLatitude(float latitude) {
  return height/2 - latitude*height/180;
}

public float transfromLongitude(float longitude) {
  return width/2 + longitude*width/360;
}
class Table {
  int rowCount;
  String[] ips;
  float[][] positions;
  long[] times;
  long min_time;
  long max_time;
  long interval;
  Table(String fileName) {
    String[] rows = loadStrings(fileName);
    rowCount = rows.length;
    ips = new String[rowCount];
    positions = new float[rowCount][2];
    times = new long[rowCount];
    
    for(int i = 0; i < rowCount; i++) {
      String[] pieces = split(rows[i],',');
      ips[i] = pieces[3];
      times[i] = Long.parseLong(pieces[2]);
      positions[i][0] = parseFloat(pieces[5]);
      positions[i][1] = parseFloat(pieces[6]);
    }
    
    min_time = times[0];
    max_time = times[rowCount - 1];
    interval = (max_time - min_time)/10000;
  }
  
  public int getRowCount() {
    return rowCount;
  }
  
  public String getIP(int rowIndex) {
    return ips[rowIndex];
  }
  
  public long getIPTime(int rowIndex) {
    return times[rowIndex];
  }
  
  public float getIPLongitude(int rowIndex) {
    return positions[rowIndex][0];
  }
  
  public float getIPLatitude(int rowIndex) {
    return positions[rowIndex][1];
  }
  
  public long getMinTime() {
    return min_time;
  }
  
  public long getMaxTime() {
    return max_time;
  }
  
  public long getInterval() {
    return interval;
  }
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--hide-stop", "sketch_mar27b" });
  }
}
